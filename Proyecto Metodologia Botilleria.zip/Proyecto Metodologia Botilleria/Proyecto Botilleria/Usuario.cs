﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic.ApplicationServices;
using static Proyecto_Botilleria.Conexion;

namespace Proyecto_Botilleria
{
     class Usuario
    {
        private string usuario;
        private string contrasena;
        public Usuario(string _user, string _pass)
        {
            usuario = _user;
            contrasena = _pass;
    }

        public void autenticar()
        {
            //aqui deberia estar el metodo para hacer la query en la tabla usuario
        }
    }

  


}
