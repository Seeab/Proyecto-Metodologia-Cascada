﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Proyecto_Botilleria.Conexion;

namespace Proyecto_Botilleria
{
    class Productos
    {
        private string nombre_producto;
        private string cantidad_producto;
        private double precio_producto;


        public Productos(string _nombrePRO,string _cantidadPRO,double _precioPRO) {
            nombre_producto=_nombrePRO;
            cantidad_producto=_cantidadPRO;
            precio_producto=_precioPRO;
        }


        public void ingresarProductos() 
        {
         //aqui deberia estar el metodo para hacer la consulta 
        }

        public void mostrarProductos() { 
        //aqui deberia estar el metodo para hacer la consulta 
        }

        public void consultadeProductos() { }
    }
}
