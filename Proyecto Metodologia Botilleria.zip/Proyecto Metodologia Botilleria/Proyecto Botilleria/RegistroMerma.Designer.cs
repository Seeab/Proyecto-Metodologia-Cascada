﻿namespace Proyecto_Botilleria
{
    partial class RegistroMerma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmb_cantidad = new System.Windows.Forms.ComboBox();
            this.cmb_TipoMerma = new System.Windows.Forms.ComboBox();
            this.txtb_nombreP = new System.Windows.Forms.TextBox();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.txtb_descripcion = new System.Windows.Forms.RichTextBox();
            this.lbl_cantidad = new System.Windows.Forms.Label();
            this.lbl_TipoMerma = new System.Windows.Forms.Label();
            this.btn_registrarmerma = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cmb_cantidad
            // 
            this.cmb_cantidad.BackColor = System.Drawing.Color.Gainsboro;
            this.cmb_cantidad.Font = new System.Drawing.Font("Gabriola", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cmb_cantidad.ForeColor = System.Drawing.Color.Black;
            this.cmb_cantidad.FormattingEnabled = true;
            this.cmb_cantidad.Location = new System.Drawing.Point(155, 187);
            this.cmb_cantidad.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmb_cantidad.Name = "cmb_cantidad";
            this.cmb_cantidad.Size = new System.Drawing.Size(358, 43);
            this.cmb_cantidad.TabIndex = 2;
            this.cmb_cantidad.SelectedIndexChanged += new System.EventHandler(this.cmb_cantidad_SelectedIndexChanged);
            // 
            // cmb_TipoMerma
            // 
            this.cmb_TipoMerma.BackColor = System.Drawing.Color.Gainsboro;
            this.cmb_TipoMerma.Font = new System.Drawing.Font("Gabriola", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cmb_TipoMerma.ForeColor = System.Drawing.Color.Black;
            this.cmb_TipoMerma.FormattingEnabled = true;
            this.cmb_TipoMerma.Location = new System.Drawing.Point(155, 249);
            this.cmb_TipoMerma.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmb_TipoMerma.Name = "cmb_TipoMerma";
            this.cmb_TipoMerma.Size = new System.Drawing.Size(358, 43);
            this.cmb_TipoMerma.TabIndex = 3;
            this.cmb_TipoMerma.SelectedIndexChanged += new System.EventHandler(this.cmb_TipoMerma_SelectedIndexChanged);
            // 
            // txtb_nombreP
            // 
            this.txtb_nombreP.BackColor = System.Drawing.Color.Gainsboro;
            this.txtb_nombreP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtb_nombreP.Font = new System.Drawing.Font("Gabriola", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtb_nombreP.ForeColor = System.Drawing.Color.Black;
            this.txtb_nombreP.Location = new System.Drawing.Point(155, 133);
            this.txtb_nombreP.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtb_nombreP.Name = "txtb_nombreP";
            this.txtb_nombreP.Size = new System.Drawing.Size(358, 40);
            this.txtb_nombreP.TabIndex = 4;
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.BackColor = System.Drawing.Color.Transparent;
            this.lbl_nombre.Font = new System.Drawing.Font("Gabriola", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_nombre.ForeColor = System.Drawing.Color.Black;
            this.lbl_nombre.Location = new System.Drawing.Point(14, 130);
            this.lbl_nombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(122, 35);
            this.lbl_nombre.TabIndex = 5;
            this.lbl_nombre.Text = "Nombre Producto";
            // 
            // txtb_descripcion
            // 
            this.txtb_descripcion.BackColor = System.Drawing.Color.Gainsboro;
            this.txtb_descripcion.Font = new System.Drawing.Font("Gabriola", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtb_descripcion.ForeColor = System.Drawing.Color.Black;
            this.txtb_descripcion.Location = new System.Drawing.Point(21, 331);
            this.txtb_descripcion.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtb_descripcion.Name = "txtb_descripcion";
            this.txtb_descripcion.Size = new System.Drawing.Size(492, 164);
            this.txtb_descripcion.TabIndex = 6;
            this.txtb_descripcion.Text = "";
            // 
            // lbl_cantidad
            // 
            this.lbl_cantidad.AutoSize = true;
            this.lbl_cantidad.BackColor = System.Drawing.Color.Transparent;
            this.lbl_cantidad.Font = new System.Drawing.Font("Gabriola", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_cantidad.ForeColor = System.Drawing.Color.Black;
            this.lbl_cantidad.Location = new System.Drawing.Point(14, 187);
            this.lbl_cantidad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_cantidad.Name = "lbl_cantidad";
            this.lbl_cantidad.Size = new System.Drawing.Size(71, 35);
            this.lbl_cantidad.TabIndex = 7;
            this.lbl_cantidad.Text = "Cantidad";
            // 
            // lbl_TipoMerma
            // 
            this.lbl_TipoMerma.AutoSize = true;
            this.lbl_TipoMerma.BackColor = System.Drawing.Color.Transparent;
            this.lbl_TipoMerma.Font = new System.Drawing.Font("Gabriola", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_TipoMerma.ForeColor = System.Drawing.Color.Black;
            this.lbl_TipoMerma.Location = new System.Drawing.Point(14, 249);
            this.lbl_TipoMerma.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_TipoMerma.Name = "lbl_TipoMerma";
            this.lbl_TipoMerma.Size = new System.Drawing.Size(104, 35);
            this.lbl_TipoMerma.TabIndex = 8;
            this.lbl_TipoMerma.Text = "Tipo de merma";
            // 
            // btn_registrarmerma
            // 
            this.btn_registrarmerma.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_registrarmerma.FlatAppearance.BorderSize = 0;
            this.btn_registrarmerma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_registrarmerma.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_registrarmerma.ForeColor = System.Drawing.Color.Black;
            this.btn_registrarmerma.Location = new System.Drawing.Point(21, 520);
            this.btn_registrarmerma.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_registrarmerma.Name = "btn_registrarmerma";
            this.btn_registrarmerma.Size = new System.Drawing.Size(492, 51);
            this.btn_registrarmerma.TabIndex = 9;
            this.btn_registrarmerma.Text = "Registrar";
            this.btn_registrarmerma.UseVisualStyleBackColor = false;
            this.btn_registrarmerma.Click += new System.EventHandler(this.btn_registrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Gabriola", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(14, 290);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 35);
            this.label1.TabIndex = 10;
            this.label1.Text = "Descripción";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto_Botilleria.Properties.Resources.Banner_de_mermas_;
            this.pictureBox1.Location = new System.Drawing.Point(-38, -47);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(635, 220);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // RegistroMerma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(546, 593);
            this.Controls.Add(this.btn_registrarmerma);
            this.Controls.Add(this.lbl_TipoMerma);
            this.Controls.Add(this.lbl_cantidad);
            this.Controls.Add(this.txtb_descripcion);
            this.Controls.Add(this.lbl_nombre);
            this.Controls.Add(this.txtb_nombreP);
            this.Controls.Add(this.cmb_TipoMerma);
            this.Controls.Add(this.cmb_cantidad);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "RegistroMerma";
            this.Text = "Registro de Merma";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cmb_cantidad;
        private System.Windows.Forms.ComboBox cmb_TipoMerma;
        private System.Windows.Forms.TextBox txtb_nombreP;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.RichTextBox txtb_descripcion;
        private System.Windows.Forms.Label lbl_cantidad;
        private System.Windows.Forms.Label lbl_TipoMerma;
        private System.Windows.Forms.Button btn_registrarmerma;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}