﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Proyecto_Botilleria.Conexion;
using System.Windows.Forms;

namespace Proyecto_Botilleria
{
    class Mermas
    {

        private string nombre_merma;
        private int cantidad_merma;
        private string tipo_merma;
        private string descripcion_merma;

        public Mermas(string _nombreP, int _cantidadP, string _tipoM, string _descripcionM)
        {
            nombre_merma = _nombreP;
            cantidad_merma = _cantidadP;
            tipo_merma = _tipoM;
            descripcion_merma = _descripcionM;

        }


        public void ingresarMerma()
        {

            Conexion connect = new Conexion();
            // escribir la query
            string query = string.Format("call sp_ingresarmerma('{0}','{1}','{2}','{3}');", nombre_merma, cantidad_merma, tipo_merma, descripcion_merma);
            // tomar la query y ejecutarla con los metodos de conexion
            connect.setQuery(query);
            connect.EjecutarConsulta();
            MessageBox.Show("Merma Registrada Exitosamente");


        }

        public void mostrarMerma() { 
        
        // aqui deberia estar el metodo para hacer la query
        }


    }
}

