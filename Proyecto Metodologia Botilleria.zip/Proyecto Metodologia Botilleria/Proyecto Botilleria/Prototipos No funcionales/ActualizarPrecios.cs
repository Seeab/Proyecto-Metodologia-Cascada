﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MVC
{
    public partial class ActualizarPrecios : Form
    {
        public ActualizarPrecios()
        {
            InitializeComponent();
        }

        public void cargarProducto() { 
        //aqui deberia estar un metodo para rellenar el combobox de los productos
        }
    }
}
