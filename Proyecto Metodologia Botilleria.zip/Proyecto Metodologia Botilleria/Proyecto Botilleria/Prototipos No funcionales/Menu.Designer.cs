﻿namespace MVC
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_listarprecios = new System.Windows.Forms.Button();
            this.btn_actualizarprecios = new System.Windows.Forms.Button();
            this.btn_actualizarstock = new System.Windows.Forms.Button();
            this.btn_listamerma = new System.Windows.Forms.Button();
            this.btn_ingresarmerma = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_ingresarproductos = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_listarprecios
            // 
            this.btn_listarprecios.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_listarprecios.FlatAppearance.BorderSize = 0;
            this.btn_listarprecios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_listarprecios.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_listarprecios.ForeColor = System.Drawing.Color.Black;
            this.btn_listarprecios.Location = new System.Drawing.Point(340, 77);
            this.btn_listarprecios.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_listarprecios.Name = "btn_listarprecios";
            this.btn_listarprecios.Size = new System.Drawing.Size(218, 38);
            this.btn_listarprecios.TabIndex = 0;
            this.btn_listarprecios.Text = "Lista Precios";
            this.btn_listarprecios.UseVisualStyleBackColor = false;
            // 
            // btn_actualizarprecios
            // 
            this.btn_actualizarprecios.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_actualizarprecios.FlatAppearance.BorderSize = 0;
            this.btn_actualizarprecios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_actualizarprecios.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_actualizarprecios.ForeColor = System.Drawing.Color.Black;
            this.btn_actualizarprecios.Location = new System.Drawing.Point(340, 122);
            this.btn_actualizarprecios.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_actualizarprecios.Name = "btn_actualizarprecios";
            this.btn_actualizarprecios.Size = new System.Drawing.Size(218, 38);
            this.btn_actualizarprecios.TabIndex = 1;
            this.btn_actualizarprecios.Text = "Actualizar Precios";
            this.btn_actualizarprecios.UseVisualStyleBackColor = false;
            // 
            // btn_actualizarstock
            // 
            this.btn_actualizarstock.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_actualizarstock.FlatAppearance.BorderSize = 0;
            this.btn_actualizarstock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_actualizarstock.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_actualizarstock.ForeColor = System.Drawing.Color.Black;
            this.btn_actualizarstock.Location = new System.Drawing.Point(340, 167);
            this.btn_actualizarstock.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_actualizarstock.Name = "btn_actualizarstock";
            this.btn_actualizarstock.Size = new System.Drawing.Size(218, 38);
            this.btn_actualizarstock.TabIndex = 2;
            this.btn_actualizarstock.Text = "Actualizar Stock";
            this.btn_actualizarstock.UseVisualStyleBackColor = false;
            // 
            // btn_listamerma
            // 
            this.btn_listamerma.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_listamerma.FlatAppearance.BorderSize = 0;
            this.btn_listamerma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_listamerma.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_listamerma.ForeColor = System.Drawing.Color.Black;
            this.btn_listamerma.Location = new System.Drawing.Point(340, 212);
            this.btn_listamerma.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_listamerma.Name = "btn_listamerma";
            this.btn_listamerma.Size = new System.Drawing.Size(218, 38);
            this.btn_listamerma.TabIndex = 3;
            this.btn_listamerma.Text = "Lista Mermas";
            this.btn_listamerma.UseVisualStyleBackColor = false;
            // 
            // btn_ingresarmerma
            // 
            this.btn_ingresarmerma.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_ingresarmerma.FlatAppearance.BorderSize = 0;
            this.btn_ingresarmerma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ingresarmerma.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_ingresarmerma.ForeColor = System.Drawing.Color.Black;
            this.btn_ingresarmerma.Location = new System.Drawing.Point(340, 257);
            this.btn_ingresarmerma.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_ingresarmerma.Name = "btn_ingresarmerma";
            this.btn_ingresarmerma.Size = new System.Drawing.Size(218, 38);
            this.btn_ingresarmerma.TabIndex = 4;
            this.btn_ingresarmerma.Text = "Ingresar Mermas";
            this.btn_ingresarmerma.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Gabriola", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(338, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 59);
            this.label1.TabIndex = 5;
            this.label1.Text = "Menú Botilleria";
            // 
            // btn_ingresarproductos
            // 
            this.btn_ingresarproductos.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_ingresarproductos.FlatAppearance.BorderSize = 0;
            this.btn_ingresarproductos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ingresarproductos.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_ingresarproductos.ForeColor = System.Drawing.Color.Black;
            this.btn_ingresarproductos.Location = new System.Drawing.Point(340, 302);
            this.btn_ingresarproductos.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btn_ingresarproductos.Name = "btn_ingresarproductos";
            this.btn_ingresarproductos.Size = new System.Drawing.Size(218, 38);
            this.btn_ingresarproductos.TabIndex = 6;
            this.btn_ingresarproductos.Text = "Ingresar Productos";
            this.btn_ingresarproductos.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = global::Proyecto_Botilleria.Properties.Resources.Menu_Botilleria_Transparente;
            this.pictureBox1.Location = new System.Drawing.Point(-69, -43);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(464, 444);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(584, 359);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_ingresarproductos);
            this.Controls.Add(this.btn_ingresarmerma);
            this.Controls.Add(this.btn_listamerma);
            this.Controls.Add(this.btn_actualizarstock);
            this.Controls.Add(this.btn_actualizarprecios);
            this.Controls.Add(this.btn_listarprecios);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Menu";
            this.Text = "Sistema Botilleria";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_listarprecios;
        private System.Windows.Forms.Button btn_actualizarprecios;
        private System.Windows.Forms.Button btn_actualizarstock;
        private System.Windows.Forms.Button btn_listamerma;
        private System.Windows.Forms.Button btn_ingresarmerma;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_ingresarproductos;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}