﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Proyecto_Botilleria
{
    class Conexion
    {
        public MySqlConnection con;
        public string query;

        static string server = "localhost";
        static string database = "Botilleria";
        static string user = "root";
        static string password = "1234";

        public string conString = string.Format("server={0};uid={1};pwd={2};database={3}",
                                                server, user, password, database);

        //Metodos
        public void setQuery(string _query)
        {
            query = _query;
        }


        public void EjecutarConsulta()
        {
            try
            {
                using (con = new MySqlConnection(conString))
                {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand(query, con);
                    // que ejecute la query, pero no devuelve nada
                    cmd.ExecuteNonQuery();
                }
            }
            // en caso de que falle sale un error
            catch (MySqlException ex)
            {
                MessageBox.Show("Error : {0}", ex.Message);
            }

        }


    }


}
