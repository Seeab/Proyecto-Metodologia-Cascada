﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Proyecto_Botilleria
{
    public partial class RegistroMerma : Form
    {
        public RegistroMerma()
        {
            //inicia el form y los metodos dentro de este
            InitializeComponent();
            cargarCantidad();
            cargarTipo();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_registrar_Click(object sender, EventArgs e)
        {
            // toma los datos tanto de los textbox, como los combobox seleccionados
            string nombre_merma = txtb_nombreP.Text;
            int cantidad_merma = cmb_cantidad.SelectedIndex;
            string tipo_merma = cmb_TipoMerma.Text;
            string descripcion_merma = txtb_descripcion.Text;

            // instancia merma
            Mermas merma = new Mermas(nombre_merma, cantidad_merma, tipo_merma, descripcion_merma);

            //verifica cada campo buscando si esta vacio o no, si esta vacio muestra un error.
            if (string.IsNullOrEmpty(cmb_TipoMerma.Text))
            {
                MessageBox.Show("Error: Falta seleccionar el tipo de merma, debe seleccionar un tipo");
            }
            else if (string.IsNullOrEmpty(cmb_cantidad.Text))
            {
                MessageBox.Show("Error: Falta seleccionar la cantidad de productos, debe seleccionar una cantidad");
            }
            else if (string.IsNullOrEmpty(txtb_nombreP.Text)) {
                MessageBox.Show("Error: Falta ingresar nombre de producto, debe ingresar un nombre");
            }
            else if (string.IsNullOrEmpty(txtb_descripcion.Text))
            {
                MessageBox.Show("Error: Falta ingresar una descripción de la merma, debe ingresar una descripción");
            }
            else
            {
                // llama el metodo utilizando los datos antes puestos
                merma.ingresarMerma();
                BorrarDatos();
            }


        }


        // borra lo escrito y seleccionado en el formulario
        public void BorrarDatos() {
        
            txtb_nombreP.Text = "";
            cmb_cantidad.SelectedItem = null;
            cmb_TipoMerma.SelectedItem = null;
            txtb_descripcion.Text = "";
        }

        //para rellenar el combobox de cantidad de productos
        public void cargarCantidad() {
            // un for para que se agreguen la cantidad de numero dentro del combobox, el maximo será 24 productos por registro de merma
            for (int i = 1; i < 25; i++)
            {
                cmb_cantidad.Items.Add(i);
            }
        }

        //para rellenar el combobox de tipo de merma
        public void cargarTipo() {
            cmb_TipoMerma.Items.Add("Operacional");
            cmb_TipoMerma.Items.Add("Devolución");
            cmb_TipoMerma.Items.Add("Caducado");
        }


        private void cmb_cantidad_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmb_TipoMerma_SelectedIndexChanged(object sender, EventArgs e)
        {
     
        }
    }
}
