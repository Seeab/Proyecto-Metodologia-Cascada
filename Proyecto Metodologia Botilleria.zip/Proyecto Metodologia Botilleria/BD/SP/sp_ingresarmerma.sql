/*
Autor: Roberto Ibarra
Fecha:15/11/2022
Nombre:sp_ingresarmerma
Descripción: es un SP que sirve para registrar una merma dento de la base de datos.
*/

delimiter $$
create procedure sp_ingresarmerma(
IN _nombre varchar(255),
IN _cantidad smallint,
IN _tipo varchar(100),
IN _descripcion varchar(200) )
Begin
insert into merma(nombre_producto,cantidad_producto,tipo_merma,descripcion_merma)
Values (_nombre,_cantidad,_tipo,_descripcion);
End
$$

-- datos de prueba del SP para ingresar mermas
call sp_ingresarmerma("cerveza",4,"operacional","venia con la tapa media abierta");
call sp_ingresarmerma("bebida",2,"operacional","en mal estado");

select * from merma;