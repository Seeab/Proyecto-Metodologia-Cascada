create database Botilleria;
use Botilleria;

create table usuario(
IDusuario int auto_increment primary key,
user varchar(100),
pass varchar(200)
);

create table merma(
IDmerma int auto_increment primary key,
Nombre_producto varchar(255),
Cantidad_producto smallint,
Tipo_merma varchar(100),
Descripcion_merma varchar(200)
);


create table producto(
IDproducto int auto_increment primary key,
Nombre_producto varchar(100),
Cantidad int,
Precio double
);


-- Datos para probar BD
insert into usuario(user,pass)
values("admin","admin");


INSERT INTO producto(Nombre_producto,Cantidad,Precio)
VALUES("Yogurt",24,250),("Coca cola",24,800);

insert into merma(Nombre_producto,Cantidad_producto,Tipo_merma,Descripcion_merma)
Values ("Yogurt Colun",1,"Devolución","Se rompio al momento de venta, cliente se le cayo al suelo");

select * from usuario;
select * from producto;
select * from merma;


/*
Autor: Roberto Ibarra
Fecha:15/11/2022
Nombre:sp_ingresarmerma
Descripción: sirve para registrar una merma
*/
delimiter $$
create procedure sp_ingresarmerma(
IN _nombre varchar(255),
IN _cantidad smallint,
IN _tipo varchar(100),
IN _descripcion varchar(200) )
Begin
insert into merma(nombre_producto,cantidad_producto,tipo_merma,descripcion_merma)
Values (_nombre,_cantidad,_tipo,_descripcion);
End
$$

-- datos de prueba del SP para ingresar mermas
call sp_ingresarmerma("cerveza",4,"operacional","venia con la tapa media abierta");
call sp_ingresarmerma("bebida",2,"operacional","en mal estado");

select * from merma;
