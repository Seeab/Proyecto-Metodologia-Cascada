create database Botilleria;
use Botilleria;

create table usuario(
IDusuario int auto_increment primary key,
user varchar(100),
pass varchar(200)
);

create table merma(
IDmerma int auto_increment primary key,
Nombre_producto varchar(255),
Cantidad_producto smallint,
Tipo_merma varchar(100),
Descripcion_merma varchar(200)
);


create table producto(
IDproducto int auto_increment primary key,
Nombre_producto varchar(100),
Cantidad int,
Precio double
);