/*
Autor: Roberto Ibarra
Fecha:15/11/2022
Nombre:Ingresar datos de prueba para cada tabla
Descripción: se insertan datos de prueba para comprobar la funcion de las tablas
*/
insert into usuario(user,pass)
values("admin","admin");

INSERT INTO producto(Nombre_producto,Cantidad,Precio)
VALUES("Yogurt",24,250),("Coca cola",24,800);

insert into merma(Nombre_producto,Cantidad_producto,Tipo_merma,Descripcion_merma)
Values ("Yogurt Colun",1,"Devolución","Se rompio al momento de venta, cliente se le cayo al suelo");

select * from usuario;
select * from producto;
select * from merma;